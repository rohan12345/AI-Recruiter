# AI Recruiter — Workflow Reference

Detailed phase-by-phase guide for every step of the recruiting workflow.

---

## Phase 0 — Structured Intake

Before sourcing a single candidate, Claude runs a structured intake to calibrate the search. Answers to these questions determine everything downstream — sourcing filters, scoring weights, outreach tone, and scheduling constraints.

### Section A — Role Basics
1. Exact role title and level (e.g. Head of Engineering, VP; L7)
2. Number of positions
3. Urgency / timeline (< 4 weeks / 4–8 weeks / 8+ weeks)
4. New role or backfill? If backfill — why did the previous person leave?

### Section B — Company & Domain Context
5. Industry / vertical
6. Specific domain of this role (e.g. payments infra, ML personalization, fantasy gaming)
7. Company stage (Seed / Series A–B / Series C+ / Late stage / Public)
8. Team size for this function

### Section C — Location & Work Model
9. Where the role is based (city or remote)
10. Work model (fully in-office / hybrid — which days / fully remote)

### Section D — Compensation
11. Fixed CTC range (annual)
12. ESOP / equity (if any)
13. Signing / joining bonus (if any)
14. Notice period flexibility

### Section E — Requirements
15. Must-haves — maximum 3, truly non-negotiable
16. Nice-to-haves — ideal but not blocking
17. Deal-breakers — automatic rejection signals

### Section F — Bar-raiser Profile
18. Describe the best person you've ever seen in this or a similar role. What made them exceptional?

### Section G — Benchmark Companies
19. Name 6–8 companies where your ideal candidate currently works or recently worked. These are your sourcing pools — the more specific the better.

### Section H — Sample Profiles
20. Share 5 profiles you'd consider strong candidates:
    - LinkedIn URL, or
    - Name + current company, or
    - Description ("someone like: 5 yrs at Swiggy, ran ML for ETA, Python + TF")
    
    Include at least 1 "stretch" (slightly above bar) and 1 "borderline" if possible.

### Section I — Interview Panel
21. Number of rounds
22. For each round: who takes it (name, title, email) and what type (Technical, System Design, Culture, Case Study, Leadership)
23. Is the hiring captain taking Round 1?

---

## Phase 1 — Market Intelligence

After intake, Claude generates a market brief covering:

- **Talent availability** — how many people matching your criteria exist in your benchmark company pools
- **Title landscape** — what this role is called across companies (title synonyms for LinkedIn search)
- **Seniority calibration** — typical tenure and level at benchmark companies for this profile
- **Compensation benchmarks** — typical CTC, ESOP, and notice period ranges
- **Competitor hiring activity** — which companies are actively hiring for similar roles
- **Sourcing strategy** — recommended search approach, filters, and prioritization

Review this brief and correct any wrong assumptions before sourcing begins.

---

## Phase 2 — Candidate Sourcing (Agent 1)

Claude searches LinkedIn using:
- Benchmark company names from intake
- Title synonyms from market intelligence
- Must-have keywords and experience signals

**Output:** A ranked candidate shortlist with:
- Name, current role, company, tenure
- Fit score (0–100) with reasoning
- Must-have coverage (which ones are met/not met)
- Deal-breaker flags
- Sourcing signal (why this person surfaced)

**Your action:** For each candidate, mark:
- ✅ Proceed to outreach
- ❌ Reject — and give a brief reason (this is how the memory learns)
- ⏸ Hold for later

---

## Phase 3 — Memory-Weighted Scoring

Candidates are scored across three dimensions using weights from `recruiter-memory.json`:

```
Final Score = (Must-have coverage × 0.50)
            + (Deal-breaker absence × 0.30)
            + (Bar-raiser signal match × 0.20)
```

Weights adjust over time. If you reject 5 candidates for "no product tech experience," the deal-breaker weight for that signal increases automatically.

**Score tiers:**
- 80–100 → Strong fit, prioritize outreach
- 60–79  → Good fit, worth reaching out
- 40–59  → Borderline, use for calibration only
- < 40   → Skip

---

## Phase 4 — Outreach (Agent 2)

For each approved candidate, Claude drafts a personalized LinkedIn message using:
- The candidate's specific background (company, tenure, notable work)
- Your role's most compelling selling points
- A clear, low-friction call to action

**Message principles:**
- Under 300 characters for LinkedIn InMail (higher response rate)
- Lead with something specific to the candidate — not a generic pitch
- One ask only: "Would you be open to a quick 20-min call?"

**You review every message before it's sent.** Nothing goes out without your approval.

**Reply monitoring:** After sending, Claude checks for replies every 6 hours for the first 48 hours and surfaces interested candidates immediately.

---

## Phase 5 — Scheduling

For interested candidates, Claude:
1. Checks calendar availability for the candidate and interviewer(s)
2. Proposes 3 time slots that work for both parties
3. Sends calendar invites to candidate and interviewer simultaneously
4. Logs the scheduled interview to your ATS / Notion tracker (if connected)

**Round 1 default:** 30-minute introductory call with hiring captain unless you specify otherwise.

---

## Phase 6 — Self-Learning Loop

After each interview or hire/pass decision, Claude updates `recruiter-memory.json`:

- **Hired** → All signals from this candidate's profile get positive weight
- **Rejected post-interview** → The rejection reason and associated signals get negative weight
- **Ghosted / withdrew** → Noted but not scored (no signal quality data)

Over time, scoring becomes more precise for your specific hiring taste — a profile that would have scored 65 in your first search might score 82 in your fifth because the model has learned what "great" means for your team.

---

## Memory File Structure

`recruiter-memory.json` tracks:

```json
{
  "searches": [
    {
      "role": "Head of Engineering",
      "date": "2024-01",
      "outcome": "hired",
      "hired_profile": { "company": "PhonePe", "tenure_yrs": 4, "team_scaled": "8→45" },
      "rejected_signals": ["pure infra background", "no hypergrowth exp"],
      "benchmark_companies_that_yielded": ["PhonePe", "Razorpay"]
    }
  ],
  "scoring_weights": {
    "must_haves": 0.50,
    "deal_breakers": 0.30,
    "bar_raiser_signals": 0.20
  },
  "strong_positive_signals": [],
  "strong_negative_signals": []
}
```

---

## Common Scenarios

### "I don't have sample profiles yet"
Skip Section H during intake and proceed. Claude will use benchmark companies and must-haves alone for sourcing. Add sample profiles after your first shortlist — you'll quickly identify which ones look right and which don't.

### "I want to defer comp range"
Fine — skip Section D. Claude will source without a comp filter. You'll need comp data before outreach drafts are finalized.

### "Interview panel isn't decided yet"
Skip Section I. Claude proceeds through sourcing and outreach. Scheduling phase is blocked until panel is confirmed — Claude will prompt you to complete it when you get there.

### "LinkedIn Recruiter isn't available"
Claude can generate Boolean search strings you can run manually in LinkedIn basic search, or suggest alternative sourcing channels (AngelList, GitHub, conference speaker lists, etc.).

---

## Outreach Message Templates

Claude adapts tone and format based on the role level:

**IC / Senior IC roles** — Lead with technical credibility and interesting problems to solve
**Manager / Director roles** — Lead with team scope, growth opportunity, and business impact
**VP / C-suite roles** — Lead with company trajectory, mission, and strategic scope; keep it short

All messages are personalized per candidate — the templates are guidelines, not copy-paste.
