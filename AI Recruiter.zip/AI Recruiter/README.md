# AI Recruiter

A Claude-powered recruiting workflow that automates the full hiring funnel — structured role intake, market intelligence, candidate sourcing, scoring, personalized outreach, and interview scheduling. Gets smarter over time by learning your hiring taste from past decisions.

---

## What It Does

The AI Recruiter runs in two agent phases covering the full pipeline:

```
Role Brief / JD
      │
      ▼
Phase 0 — Structured Intake        ← Captures role requirements, benchmarks, sample profiles
      │
      ▼
Phase 1 — Market Intelligence      ← Talent availability, competitor hiring, sourcing strategy
      │
      ▼
Phase 2 — Candidate Sourcing       ← LinkedIn search using benchmark companies + title synonyms
      │
      ▼
Phase 3 — Scoring & Shortlist      ← Memory-weighted scoring against must-haves & deal-breakers
      │
      ▼
Phase 4 — Outreach                 ← Personalized messages drafted, sent, replies monitored
      │
      ▼
Phase 5 — Scheduling               ← Calendar check, dual invites sent to candidate + interviewer
      │
      ▼
Phase 6 — Learning Loop            ← Outcomes logged to recruiter-memory.json for future sessions
```

---

## How to Use

### Prerequisites
- Claude (claude.ai or Claude desktop app)
- LinkedIn Recruiter or Sales Navigator (for sourcing phase)
- Google Calendar or similar (for scheduling phase)
- A text editor to maintain `recruiter-memory.json`

### Step 1 — Copy the system prompt

Open `system-prompt.md` and paste its contents as a **System Prompt** in your Claude project, or paste it at the start of your conversation.

### Step 2 — Start a session

Paste your JD and say:

```
Here is the JD I want you to work on:
[paste JD]
```

Or describe the role:

```
I need to hire a Head of Engineering (VP level) for a 200-person fintech startup in Mumbai.
```

### Step 3 — Complete Structured Intake

Claude will walk you through 9 intake sections. The more you fill in, the better the sourcing. The three sections that most impact quality:

- **Benchmark companies** — 6–8 companies whose engineers you want to hire
- **Sample profiles** — 5 people you'd hire; teaches Claude your taste
- **Deal-breakers** — what auto-disqualifies a candidate

### Step 4 — Review Market Intelligence

Claude generates a brief covering talent availability, typical comp ranges, and sourcing strategy. Correct any wrong assumptions before sourcing begins.

### Step 5 — Candidate Sourcing

Claude searches LinkedIn using your benchmark companies and title synonyms. It returns a ranked shortlist. For each candidate you mark:
- ✅ Proceed to outreach
- ❌ Reject (with reason — this trains the memory)
- ⏸ Hold

### Step 6 — Outreach

Claude drafts a personalized message for each approved candidate. You review, edit if needed, and confirm. Claude monitors for replies and surfaces interested candidates.

### Step 7 — Scheduling

For interested candidates, Claude checks calendars and sends invites to both candidate and interviewer(s).

### Step 8 — Log Outcomes

After each hire or pass decision, tell Claude the outcome and reason. It updates `recruiter-memory.json` to improve scoring in future searches.

---

## Files

```
ai-recruiter/
├── README.md                        ← This file
├── system-prompt.md                 ← Paste into Claude as system prompt
├── recruiter-memory.template.json   ← Copy → rename to recruiter-memory.json
└── WORKFLOW.md                      ← Phase-by-phase reference guide
```

---

## recruiter-memory.json

This file is the brain of the system. It persists your hiring taste across sessions:

- Roles hired for and their calibration data
- Benchmark companies that yielded strong candidates
- Scoring weights per signal type
- Candidate outcomes (hired, rejected, ghosted, withdrew)
- Rejection reasons (used to improve future filtering)

**Setup:** Copy `recruiter-memory.template.json`, rename to `recruiter-memory.json`, keep it in your working directory. Tell Claude where it is at the start of each session — Claude reads and updates it automatically.

---

## Intake Reference — All 9 Sections

| Section | What You Provide |
|---------|-----------------|
| A — Role Basics | Title, level, headcount, urgency, new/backfill |
| B — Company Context | Industry, domain, company stage, team size |
| C — Location & Work Model | City, remote/hybrid/in-office |
| D — Compensation | CTC range, ESOP, signing bonus |
| E — Requirements | Must-haves (max 3), nice-to-haves, deal-breakers |
| F — Bar-raiser Profile | What exceptional looks like for this role |
| G — Benchmark Companies | 6–8 talent pools to source from |
| H — Sample Profiles | 5 reference candidates (LinkedIn URLs or descriptions) |
| I — Interview Panel | Round structure, owners, scheduling constraints |

---

## Scoring System

Each candidate is scored against three dimensions, weighted by `recruiter-memory.json`:

| Dimension | Default Weight | What It Checks |
|-----------|---------------|----------------|
| Must-haves | 50% | Non-negotiable qualifiers from intake |
| Deal-breakers | 30% | Auto-disqualifying signals |
| Bar-raiser signals | 20% | Exceptional indicators from sample profiles |

Weights adjust over time as you accept/reject candidates with reasons.

---

## Tips for Best Results

**Be specific with benchmark companies.** "PhonePe, CRED, Razorpay" is better than "fintech companies." The more specific the talent pool, the tighter the sourcing.

**Share real sample profiles.** 5 LinkedIn URLs of people you'd actually hire teaches Claude your taste faster than any written description.

**Always give a reason when rejecting.** "Too corporate" or "no product tech experience" is logged and improves future scoring.

**Defer what you don't know.** Comp range and interview panel can be filled in later — skip them during intake and come back when ready.

---

## Tech Stack

- **Claude AI** — workflow orchestration, scoring, outreach drafting
- **LinkedIn Recruiter / Sales Navigator** — candidate sourcing
- **Google Calendar** — availability and invites
- **Notion / ATS** — candidate logging (optional)

---

## License

MIT — use freely, modify as needed.
